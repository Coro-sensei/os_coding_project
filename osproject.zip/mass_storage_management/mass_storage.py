import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt


class MassStorageGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Mass Storage Management")
        self.root.geometry("800x600")

        
        self.setup_gui()

    def setup_gui(self):
        tk.Label(
            self.root,
            text="Mass Storage Management Simulator",
            font=("Arial", 16, "bold")
        ).pack(pady=20)

        tk.Label(self.root, text="Disk Requests (comma separated):").pack()
        self.request_entry = tk.Entry(self.root, width=40)
        self.request_entry.pack()

        tk.Label(self.root, text="Initial Head Position:").pack()
        self.head_entry = tk.Entry(self.root, width=20)
        self.head_entry.pack()

        tk.Button(
            self.root,
            text="Run Simulation",
            command=self.run_simulation
        ).pack(pady=10)

    def run_simulation(self):
        try:
            requests = [int(x.strip()) for x in self.request_entry.get().split(",")]
            head = int(self.head_entry.get())

            # KEEP YOUR ORIGINAL GRAPHING CODE HERE
            self.show_graph(requests, head)

        except ValueError:
            messagebox.showerror("Error", "Invalid input.")

    def show_graph(self, requests, head):
        # EXAMPLE GRAPH (replace with your original graph logic)
        sequence = [head] + requests

        plt.figure(figsize=(8, 5))
        plt.plot(sequence, marker="o")
        plt.xlabel("Request Order")
        plt.ylabel("Track Number")
        plt.title("Disk Scheduling Graph")
        plt.grid(True)
        plt.show()


# 
def main():
    root = tk.Tk()
    app = MassStorageGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()